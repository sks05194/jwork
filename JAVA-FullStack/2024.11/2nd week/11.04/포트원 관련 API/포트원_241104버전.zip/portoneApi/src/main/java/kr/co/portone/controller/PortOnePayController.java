package kr.co.portone.controller;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;

import kr.co.my.order.vo.FormDatavVO;
import kr.co.my.order.vo.OrderListDetailVO;
import kr.co.my.order.vo.OrderListVO;
import kr.co.my.order.vo.ResponseVO;
import kr.co.my.order.vo.ResponseVO2;
import kr.co.portone.vo.PaymentAnnotationVO;
import kr.co.portone.vo.PortOnePayOneDetailVO;

@Controller
public class PortOnePayController {
	// 상점아이디
	// private String storeId = "자신의 상점 아이디 값 입력";
	// 연동정보 채널키
	private String channelKey = "자신이 설정한 채널키 값 입력";
	// 포트원 고객사 식별코드
	private String impCode = "v1 API에 자신의 고객사 식별코드 값 입력";
	// Rest API Key
	private String imp_key = "v1 API에 자신의 Rest API Key 값 입력";
	// REST API Secret
	private String imp_secret = "v1 API에 자신의 REST API Secret 값 입력";

	// portone hostname
	// https://developers.portone.io/api/rest-v1/auth?v=v1
	// [개요] 메뉴의 [PortOne REST API - V1] 에서 V1 API hostname참고
	String hostname = "https://api.iamport.kr";

	@ModelAttribute("portOneNeeds")
	public Map<String, String> getPortOne() {
		Map<String, String> map = new HashMap<>();
		// 상점아이디
		// map.put("storeId", storeId);
		map.put("channelKey", channelKey);
		// 포트원 고객사 식별코드
		map.put("impCode", impCode);

		return map;
	}

	// 토큰 발급받기(모든 API를 사용할 때, header에 반드시 보내야함)
	// https://developers.portone.io/api/rest-v1/payment?v=v1
	// portone hostname [개요] 메뉴의 [인증 관련 API] 참고
	// 인증 관련 API => 액세스토큰 사용하기 => 속성명 : Authorization , 속성값: Bearer 액세스토큰값
	public String getTocken() {
		System.out.println("access_token 발급 API");

		String token = "";
		String url = hostname + "/users/getToken";
		String jsonData = "{\"imp_key\":\"" + imp_key + "\",\"imp_secret\":\"" + imp_secret + "\"}";
		try {
			HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url))
					.header("Content-Type", "application/json")
					.method("POST", HttpRequest.BodyPublishers.ofString(jsonData)).build();
			HttpResponse<String> response = HttpClient.newHttpClient().send(request,
					HttpResponse.BodyHandlers.ofString());

			String jsonString = response.body(); // 필요한 응답데이터
			// System.out.println("jsonString: "+jsonString);

			// String to JSON으로 변환하기 위한 작업
			// 참고 : https://www.baeldung.com/jackson-deserialize-json-unknown-properties
			ObjectMapper mapper = new ObjectMapper();
			ResponseVO rvo = mapper.readValue(jsonString, ResponseVO.class);
			token = (String) rvo.getResponse().get("access_token");
			// System.out.println("토큰값: " + token);

		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return token;
	}

	// 결제 페이지 이동
	@RequestMapping(value = "/pay", method = RequestMethod.GET)
	public String payForm() {
		return "/WEB-INF/pay/pay.jsp";
	}

	// 결제 후 결제한 내역 받아오기
	@RequestMapping(value = "/pay", method = RequestMethod.POST)
	public String pay(@RequestBody FormDatavVO fvo, OrderListVO ovo, OrderListDetailVO odvo) {
		System.out.println("fvo: " + fvo);
		// 이곳에서 DB에 저장하는 작업 처리하기
		return "/WEB-INF/pay/payList.jsp";
	}

	@RequestMapping(value = "/payMenu", method = RequestMethod.GET)
	public String payMenu() {
		return "/WEB-INF/pay/payList.jsp";
	}

	// https://developers.portone.io/api/rest-v1/payment?v=v1 => 결제관련API
	// 결제내역 단건조회 API : get /payments/{imp_uid}
	@RequestMapping(value = "/payDetail", method = RequestMethod.POST)
	@ResponseBody
	public Object payDetail(@RequestParam(value = "imp_uid") String imp_uid) {
		System.out.println("결제내역 단건조회 API 시작");
		// 성공(ok) 실패(no)여부
		String url = hostname + "/payments/" + imp_uid;
		int code = -1;
		PortOnePayOneDetailVO vo = null;

		try {
			HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url))
					.headers("Content-Type", "application/json", "Authorization", "Bearer " + getTocken())
					.method("GET", HttpRequest.BodyPublishers.ofString("{}")).build();
			HttpResponse<String> response = HttpClient.newHttpClient().send(request,
					HttpResponse.BodyHandlers.ofString());
			String jsonString = response.body(); // 필요한 응답데이터
			// System.out.println("jsonString: "+jsonString);

			// String to JSON으로 변환하기 위한 작업
			// 참고 : https://www.baeldung.com/jackson-deserialize-json-unknown-properties
			ObjectMapper mapper = new ObjectMapper();
			ResponseVO rvo = mapper.readValue(jsonString, ResponseVO.class);
			// System.out.println(rvo.getResponse());

			code = rvo.getCode();
			// System.out.println("code: "+rvo.getCode());

			if (code > -1) {
				vo = mapper.convertValue(rvo.getResponse(), PortOnePayOneDetailVO.class);
				// System.out.println("vo: "+vo);
			}

		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}

		if (code > -1) {
			return vo;
		} else {
			return "no";
		}

	}

	// 결제내역 복수조회 API
	@RequestMapping("/paySelList")
	@ResponseBody
	public Object payList(FormDatavVO vo) {
		System.out.println("결제내역 복수조회 API");

		String url = hostname + "/payments";
		String impUidArrStr = "";
		String merchantUidArrStr = "";
		String[] impUidArr = vo.getImpUidArr();
		String[] merchantUidArr = vo.getMerchantUidArr();
		String queryString = "";
		int code = -1;

		if (impUidArr != null) {
			url += "?";
			for (int i = 0; i < impUidArr.length; i++) {
				if (i == impUidArr.length - 1)
					impUidArrStr += "imp_uid[]=" + impUidArr[i];
				else
					impUidArrStr += impUidArrStr += "imp_uid[]=" + impUidArr[i] + "&";
			}
		}

		if (impUidArr != null && merchantUidArr != null)
			impUidArrStr += "&";

		if (merchantUidArr != null) {
			if (impUidArr == null)
				url += "?";
			for (int i = 0; i < merchantUidArr.length; i++) {
				if (i == merchantUidArr.length - 1)
					merchantUidArrStr += "merchant_uid[]=" + merchantUidArr[i];
				else
					merchantUidArrStr += "merchant_uid[]=" + merchantUidArr[i] + "&";
			}
		}
		queryString = impUidArrStr + merchantUidArrStr;
		System.out.println("url: " + url + queryString);

		HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url + queryString))
				.headers("Content-Type", "application/json", "Authorization", "Bearer " + getTocken())
				.method("GET", HttpRequest.BodyPublishers.ofString("")).build();

		ArrayList<Object> arr = null;
		try {
			HttpResponse<String> response = HttpClient.newHttpClient().send(request,
					HttpResponse.BodyHandlers.ofString());
			String jsonString = response.body();

			ObjectMapper mapper = new ObjectMapper();
			ResponseVO2 rvo = mapper.readValue(jsonString, ResponseVO2.class);
			// System.out.println("rvo.getResponse(): "+rvo.getResponse());
			code = rvo.getCode();
			if (code > -1) {
				arr = rvo.getResponse();
				// System.out.println("arr: "+arr);

				for (Object obj : arr) {
					PaymentAnnotationVO pvo = mapper.convertValue(obj, PaymentAnnotationVO.class);
					System.out.println("pvo: " + pvo);

				}
			}

		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (code > -1)
			return arr;
		else
			return "no";
	}

	// 결제취소 API
	@RequestMapping("/payCancel")
	@ResponseBody
	public int payCancel(PortOnePayOneDetailVO vo) {
		int code = -1;
		String url = hostname + "/payments/cancel";
		String query ="{\"imp_uid\" : \"" + vo.getImp_uid() + "\"}";
		System.out.println("query: "+query);

		HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).headers("Content-Type", "application/json", "Authorization", "Bearer " + getTocken()).method("POST", HttpRequest.BodyPublishers.ofString(query)).build();

		try {
			HttpResponse<String> response = HttpClient.newHttpClient().send(request,
					HttpResponse.BodyHandlers.ofString());
			String jsonString = response.body(); // 필요한 응답데이터
			System.out.println("jsonString: " + jsonString);

			// String to JSON으로 변환하기 위한 작업
			// 참고 : https://www.baeldung.com/jackson-deserialize-json-unknown-properties
			ObjectMapper mapper = new ObjectMapper();
			ResponseVO rvo = mapper.readValue(jsonString, ResponseVO.class);
			 System.out.println(rvo.getMessage());

			code = rvo.getCode();
			// System.out.println("code: "+rvo.getCode());

			if (code > -1) {
				vo = mapper.convertValue(rvo.getResponse(), PortOnePayOneDetailVO.class);
				// System.out.println("vo: "+vo);
				code = 0;
			}

		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}

		return code;
	}

}
