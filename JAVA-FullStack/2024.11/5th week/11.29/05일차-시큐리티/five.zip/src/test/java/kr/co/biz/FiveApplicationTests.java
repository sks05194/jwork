package kr.co.biz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
