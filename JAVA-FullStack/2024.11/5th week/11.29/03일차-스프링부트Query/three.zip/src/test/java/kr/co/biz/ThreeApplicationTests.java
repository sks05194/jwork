package kr.co.biz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThreeApplicationTests {

	@Test
	void contextLoads() {
	}

}
