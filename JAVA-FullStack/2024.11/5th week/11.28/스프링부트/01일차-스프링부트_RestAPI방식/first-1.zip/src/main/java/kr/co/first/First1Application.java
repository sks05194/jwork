package kr.co.first;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class First1Application {

	public static void main(String[] args) {
		SpringApplication.run(First1Application.class, args);
	}

}
