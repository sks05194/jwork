package kr.co.first;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class First1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
